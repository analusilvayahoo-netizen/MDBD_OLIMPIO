import { useState } from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function HomeScreen({ navegar }) {

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <View style={styles.linhaSuperior} />

      <View style={styles.logo}>
        <Text style={styles.logoTexto}>DV</Text>
      </View>

      <Text style={styles.escola}>DA VINCI</Text>
      <Text style={styles.highSchool}>HIGH SCHOOL</Text>

      <View style={styles.divisor}>
        <View style={styles.linha} />
        <Text style={styles.simbolo}>✦</Text>
        <View style={styles.linha} />
      </View>

      <Text style={styles.titulo}>
        APP SCHOLAR
      </Text>

      <Text style={styles.subtitulo}>
        EDUCAÇÃO • INOVAÇÃO • FUTURO
      </Text>

      <View style={styles.card}>
        <Text style={styles.cardTitulo}>
          Sistema Acadêmico
        </Text>

        <Text style={styles.cardTexto}>
          Uma plataforma para facilitar a gestão
          acadêmica de alunos, professores,
          responsáveis e coordenadores.
        </Text>
      </View>

      <TouchableOpacity
        style={styles.botaoPrincipal}
        onPress={() => navegar('login')}
      >
        <Text style={styles.textoPrincipal}>
          ENTRAR NO SISTEMA
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoSecundario}
        onPress={() => navegar('sobre')}
      >
        <Text style={styles.textoSecundario}>
          CONHEÇA O SISTEMA
        </Text>
      </TouchableOpacity>

      <Text style={styles.rodape}>
        © 2026 DA VINCI HIGH SCHOOL
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    alignItems: 'center',
    paddingHorizontal: 28,
    paddingBottom: 30,
  },

  linhaSuperior: {
    width: '100%',
    height: 5,
    backgroundColor: CORES.verde,
    marginBottom: 55,
  },

  logo: {
    width: 90,
    height: 90,
    borderWidth: 2,
    borderColor: CORES.verde,
    borderRadius: 45,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },

  logoTexto: {
    fontSize: 28,
    fontWeight: 'bold',
    color: CORES.verde,
    letterSpacing: 2,
  },

  escola: {
    fontSize: 36,
    fontWeight: 'bold',
    color: CORES.verde,
    letterSpacing: 5,
  },

  highSchool: {
    fontSize: 18,
    color: CORES.verde,
    letterSpacing: 7,
    marginTop: 5,
  },

  divisor: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '75%',
    marginVertical: 25,
  },

  linha: {
    flex: 1,
    height: 1,
    backgroundColor: CORES.verde,
  },

  simbolo: {
    color: CORES.verde,
    fontSize: 18,
    marginHorizontal: 12,
  },

  titulo: {
    fontSize: 25,
    fontWeight: 'bold',
    color: CORES.verde,
    marginBottom: 8,
    letterSpacing: 2,
  },

  subtitulo: {
    fontSize: 11,
    letterSpacing: 2,
    color: CORES.cinza,
    marginBottom: 30,
  },

  card: {
    width: '100%',
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 12,
    padding: 22,
    marginBottom: 25,
  },

  cardTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    color: CORES.verde,
    textAlign: 'center',
    marginBottom: 10,
  },

  cardTexto: {
    fontSize: 15,
    lineHeight: 23,
    color: CORES.cinza,
    textAlign: 'center',
  },

  botaoPrincipal: {
    width: '100%',
    backgroundColor: CORES.verde,
    paddingVertical: 17,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 14,
  },

  textoPrincipal: {
    color: CORES.fundo,
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 2,
  },

  botaoSecundario: {
    width: '100%',
    borderWidth: 1.5,
    borderColor: CORES.verde,
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
  },

  textoSecundario: {
    color: CORES.verde,
    fontSize: 14,
    fontWeight: 'bold',
    letterSpacing: 1,
  },

  rodape: {
    marginTop: 35,
    fontSize: 10,
    color: '#888888',
    letterSpacing: 1,
  },
});
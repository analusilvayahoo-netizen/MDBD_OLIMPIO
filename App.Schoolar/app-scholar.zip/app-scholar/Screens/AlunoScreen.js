import React, { useState } from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';

import { CORES } from './Cores';

export default function AlunoScreen({
  usuario,
  alunos,
  adicionarAluno,
  excluirAluno,
  navegar,
}) {
  const [modo, setModo] = useState('consulta');

  const [nome, setNome] = useState('');
  const [idade, setIdade] = useState('');
  const [email, setEmail] = useState('');
  const [turma, setTurma] = useState('');

  const [busca, setBusca] = useState('');

  const podeCadastrar =
    usuario.perfil === 'coordenador';

  function cadastrar() {
    if (!nome || !idade || !email || !turma) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );
      return;
    }

    adicionarAluno({
      nome,
      idade,
      email,
      turma,
    });

    setNome('');
    setIdade('');
    setEmail('');
    setTurma('');

    setModo('consulta');

    Alert.alert(
      'Sucesso',
      'Aluno cadastrado com sucesso!'
    );
  }

  const alunosFiltrados = alunos.filter((aluno) =>
    aluno.nome
      .toLowerCase()
      .includes(busca.toLowerCase())
  );

  function remover(id) {
    Alert.alert(
      'Excluir aluno',
      'Deseja realmente excluir este aluno?',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Excluir',
          onPress: () => excluirAluno(id),
        },
      ]
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity
        onPress={() => navegar('dashboard')}
      >
        <Text style={styles.voltar}>
          ‹ Voltar
        </Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>
        ALUNOS
      </Text>

      <Text style={styles.subtitulo}>
        Cadastro e consulta de alunos
      </Text>

      {podeCadastrar && (
        <View style={styles.abas}>
          <TouchableOpacity
            style={[
              styles.aba,
              modo === 'consulta' && styles.abaAtiva,
            ]}
            onPress={() => setModo('consulta')}
          >
            <Text style={styles.abaTexto}>
              CONSULTAR
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.aba,
              modo === 'cadastro' && styles.abaAtiva,
            ]}
            onPress={() => setModo('cadastro')}
          >
            <Text style={styles.abaTexto}>
              CADASTRAR
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {modo === 'cadastro' && podeCadastrar ? (
        <View>
          <Text style={styles.label}>
            NOME COMPLETO
          </Text>

          <TextInput
            style={styles.input}
            value={nome}
            onChangeText={setNome}
            placeholder="Nome do aluno"
          />

          <Text style={styles.label}>
            IDADE
          </Text>

          <TextInput
            style={styles.input}
            value={idade}
            onChangeText={setIdade}
            placeholder="Idade"
            keyboardType="numeric"
          />

          <Text style={styles.label}>
            E-MAIL
          </Text>

          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="E-mail"
            keyboardType="email-address"
          />

          <Text style={styles.label}>
            TURMA
          </Text>

          <TextInput
            style={styles.input}
            value={turma}
            onChangeText={setTurma}
            placeholder="Ex.: 3º A"
          />

          <TouchableOpacity
            style={styles.botao}
            onPress={cadastrar}
          >
            <Text style={styles.botaoTexto}>
              CADASTRAR ALUNO
            </Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View>
          <TextInput
            style={styles.input}
            value={busca}
            onChangeText={setBusca}
            placeholder="🔎 Buscar aluno..."
          />

          <Text style={styles.quantidade}>
            {alunosFiltrados.length} aluno(s)
          </Text>

          {alunosFiltrados.map((aluno) => (
            <View
              style={styles.aluno}
              key={aluno.id}
            >
              <View style={styles.avatar}>
                <Text style={styles.avatarTexto}>
                  {aluno.nome.charAt(0)}
                </Text>
              </View>

              <View style={styles.info}>
                <Text style={styles.nome}>
                  {aluno.nome}
                </Text>

                <Text style={styles.detalhe}>
                  {aluno.idade} anos • {aluno.turma}
                </Text>

                <Text style={styles.email}>
                  {aluno.email}
                </Text>
              </View>

              {podeCadastrar && (
                <TouchableOpacity
                  onPress={() => remover(aluno.id)}
                >
                  <Text style={styles.excluir}>
                    ×
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
    paddingBottom: 40,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  abas: {
    flexDirection: 'row',
    marginBottom: 20,
  },

  aba: {
    flex: 1,
    borderWidth: 1,
    borderColor: CORES.verde,
    padding: 13,
    alignItems: 'center',
  },

  abaAtiva: {
    backgroundColor: CORES.verde,
  },

  abaTexto: {
    fontWeight: 'bold',
    color: CORES.verde,
    fontSize: 12,
  },

  label: {
    fontSize: 11,
    color: CORES.cinza,
    fontWeight: 'bold',
    marginBottom: 6,
    marginTop: 10,
  },

  input: {
    borderWidth: 1,
    borderColor: CORES.borda,
    backgroundColor: CORES.branco,
    borderRadius: 8,
    padding: 14,
    fontSize: 15,
    marginBottom: 10,
  },

  botao: {
    backgroundColor: CORES.verde,
    borderRadius: 8,
    padding: 17,
    alignItems: 'center',
    marginTop: 15,
  },

  botaoTexto: {
    color: CORES.fundo,
    fontWeight: 'bold',
    letterSpacing: 1,
  },

  quantidade: {
    color: CORES.cinza,
    marginBottom: 10,
  },

  aluno: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },

  avatar: {
    width: 45,
    height: 45,
    borderRadius: 25,
    backgroundColor: CORES.verde,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },

  avatarTexto: {
    color: CORES.fundo,
    fontWeight: 'bold',
    fontSize: 18,
  },

  info: {
    flex: 1,
  },

  nome: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
  },

  detalhe: {
    color: CORES.cinza,
    fontSize: 12,
    marginTop: 4,
  },

  email: {
    color: CORES.cinza,
    fontSize: 11,
    marginTop: 3,
  },

  excluir: {
    color: '#A33',
    fontSize: 28,
    padding: 5,
  },
});
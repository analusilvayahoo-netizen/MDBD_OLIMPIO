import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function BoletimScreen({
  boletins,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>BOLETINS</Text>

      <Text style={styles.subtitulo}>
        Desempenho acadêmico
      </Text>

      {boletins.map((boletim) => (
        <View style={styles.card} key={boletim.id}>
          <Text style={styles.icone}>📋</Text>

          <View style={styles.info}>
            <Text style={styles.nome}>
              {boletim.aluno}
            </Text>

            <Text style={styles.situacao}>
              {boletim.situacao}
            </Text>
          </View>

          <View>
            <Text style={styles.mediaLabel}>
              MÉDIA
            </Text>

            <Text style={styles.media}>
              {boletim.media}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  icone: {
    fontSize: 27,
    marginRight: 15,
  },

  info: {
    flex: 1,
  },

  nome: {
    color: CORES.verde,
    fontSize: 16,
    fontWeight: 'bold',
  },

  situacao: {
    color: CORES.cinza,
    marginTop: 5,
  },

  mediaLabel: {
    fontSize: 9,
    color: CORES.cinza,
    textAlign: 'center',
  },

  media: {
    fontSize: 22,
    fontWeight: 'bold',
    color: CORES.verde,
    marginTop: 3,
  },
});
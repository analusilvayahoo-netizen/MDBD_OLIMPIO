import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function CursoScreen({
  cursos,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>CURSOS</Text>

      <Text style={styles.subtitulo}>
        Cursos disponíveis na instituição
      </Text>

      {cursos.map((curso) => (
        <View style={styles.card} key={curso.id}>
          <Text style={styles.icone}>🏫</Text>

          <View>
            <Text style={styles.nome}>
              {curso.nome}
            </Text>

            <Text style={styles.descricao}>
              {curso.descricao}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  icone: {
    fontSize: 27,
    marginRight: 15,
  },

  nome: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 17,
  },

  descricao: {
    color: CORES.cinza,
    marginTop: 5,
  },
});
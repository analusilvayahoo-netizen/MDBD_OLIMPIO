import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

const CORES = {
  fundo: '#FFFAFA',
  verde: '#0D2C1D',
  verdeClaro: '#183F2B',
  cinza: '#666666',
  borda: '#D5DDD8',
  branco: '#FFFFFF',
};

export default function DashboardScreen({
  usuario,
  navegar,
  sair,
}) {
  const perfil = usuario?.perfil || 'aluno';

  const permissoes = {
    aluno: [
      'boletins',
      'avaliacoes',
      'disciplinas',
      'turmas',
      'matriculas',
    ],

    professor: [
      'alunos',
      'disciplinas',
      'turmas',
      'avaliacoes',
    ],

    responsavel: [
      'boletins',
      'avaliacoes',
      'alunos',
    ],

    coordenador: [
      'alunos',
      'professores',
      'responsaveis',
      'cursos',
      'disciplinas',
      'matriculas',
      'turmas',
      'avaliacoes',
      'boletins',
      'coordenador',
    ],
  };

  const menus = {
    alunos: ['🎓', 'Alunos'],
    professores: ['👨‍🏫', 'Professores'],
    responsaveis: ['👨‍👩‍👧', 'Responsáveis'],
    cursos: ['🏫', 'Cursos'],
    disciplinas: ['📚', 'Disciplinas'],
    matriculas: ['📝', 'Matrículas'],
    turmas: ['👥', 'Turmas'],
    avaliacoes: ['📊', 'Avaliações'],
    boletins: ['📋', 'Boletins'],
    coordenador: ['⚙️', 'Área do Coordenador'],
  };

  const itensPermitidos = permissoes[perfil] || [];

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >

      {/* CABEÇALHO */}
      <View style={styles.cabecalho}>

        <View style={styles.informacoesUsuario}>

          <Text style={styles.pequeno}>
            BEM-VINDO
          </Text>

          <Text style={styles.nome}>
            {usuario?.nome || 'Usuário'}
          </Text>

          <Text style={styles.perfil}>
            {perfil.toUpperCase()}
          </Text>

        </View>

        <View style={styles.logo}>
          <Text style={styles.logoTexto}>
            DV
          </Text>
        </View>

      </View>

      {/* DIVISOR */}
      <View style={styles.divisor}>

        <View style={styles.linha} />

        <Text style={styles.simbolo}>
          ✦
        </Text>

        <View style={styles.linha} />

      </View>

      {/* TÍTULO */}
      <Text style={styles.titulo}>
        PAINEL PRINCIPAL
      </Text>

      <Text style={styles.subtitulo}>
        O que você deseja acessar?
      </Text>

      {/* MENUS */}
      {itensPermitidos.map((item) => {

        const menu = menus[item];

        if (!menu) {
          return null;
        }

        return (
          <TouchableOpacity
            key={item}
            style={styles.card}
            onPress={() => navegar(item)}
            activeOpacity={0.8}
          >

            <Text style={styles.cardSimbolo}>
              {menu[0]}
            </Text>

            <View style={styles.cardInfo}>

              <Text style={styles.cardTitulo}>
                {menu[1]}
              </Text>

              <Text style={styles.cardDescricao}>
                Acessar módulo
              </Text>

            </View>

            <Text style={styles.seta}>
              ›
            </Text>

          </TouchableOpacity>
        );
      })}

      {/* SAIR */}
      <TouchableOpacity
        style={styles.sair}
        onPress={sair}
        activeOpacity={0.8}
      >

        <Text style={styles.sairTexto}>
          SAIR DO SISTEMA
        </Text>

      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
    paddingBottom: 40,
  },

  cabecalho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  informacoesUsuario: {
    flex: 1,
  },

  pequeno: {
    fontSize: 10,
    color: CORES.cinza,
    letterSpacing: 2,
  },

  nome: {
    fontSize: 24,
    fontWeight: 'bold',
    color: CORES.verde,
    marginTop: 4,
  },

  perfil: {
    fontSize: 11,
    color: CORES.verdeClaro,
    marginTop: 4,
    letterSpacing: 1,
  },

  logo: {
    width: 55,
    height: 55,
    borderWidth: 1.5,
    borderColor: CORES.verde,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },

  logoTexto: {
    fontWeight: 'bold',
    fontSize: 18,
    color: CORES.verde,
    letterSpacing: 1,
  },

  divisor: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 25,
  },

  linha: {
    flex: 1,
    height: 1,
    backgroundColor: CORES.borda,
  },

  simbolo: {
    marginHorizontal: 10,
    color: CORES.verde,
    fontSize: 18,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 21,
    fontWeight: 'bold',
    letterSpacing: 1,
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 20,
    fontSize: 14,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 17,
    backgroundColor: CORES.branco,
    marginBottom: 12,
  },

  cardSimbolo: {
    fontSize: 25,
    marginRight: 15,
  },

  cardInfo: {
    flex: 1,
  },

  cardTitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: CORES.verde,
  },

  cardDescricao: {
    fontSize: 12,
    color: CORES.cinza,
    marginTop: 4,
  },

  seta: {
    fontSize: 28,
    color: CORES.verde,
  },

  sair: {
    borderWidth: 1,
    borderColor: '#A33',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginTop: 20,
  },

  sairTexto: {
    color: '#A33',
    fontWeight: 'bold',
    letterSpacing: 1,
  },

});
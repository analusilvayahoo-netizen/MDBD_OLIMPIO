import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function ProfessorScreen({
  professores,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity
        onPress={() => navegar('dashboard')}
      >
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>
        PROFESSORES
      </Text>

      <Text style={styles.subtitulo}>
        Professores cadastrados
      </Text>

      {professores.map((professor) => (
        <View style={styles.card} key={professor.id}>
          <View style={styles.avatar}>
            <Text>👨‍🏫</Text>
          </View>

          <View style={styles.info}>
            <Text style={styles.nome}>
              {professor.nome}
            </Text>

            <Text style={styles.detalhe}>
              Disciplina: {professor.disciplina}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: CORES.verde,
  },

  subtitulo: {
    color: CORES.cinza,
    marginBottom: 25,
    marginTop: 5,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 17,
    marginBottom: 12,
  },

  avatar: {
    width: 45,
    height: 45,
    borderRadius: 25,
    backgroundColor: '#EEF3EF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },

  info: {
    flex: 1,
  },

  nome: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
  },

  detalhe: {
    color: CORES.cinza,
    marginTop: 5,
  },
});
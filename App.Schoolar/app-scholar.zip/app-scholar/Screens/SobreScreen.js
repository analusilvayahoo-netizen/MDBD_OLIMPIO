import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function SobreScreen({ navegar }) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('home')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <View style={styles.logo}>
        <Text style={styles.logoTexto}>DV</Text>
      </View>

      <Text style={styles.titulo}>
        APP SCHOLAR
      </Text>

      <Text style={styles.subtitulo}>
        SISTEMA ACADÊMICO MOBILE
      </Text>

      <View style={styles.divisor}>
        <View style={styles.linha} />
        <Text style={styles.simbolo}>✦</Text>
        <View style={styles.linha} />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitulo}>
          Sobre o sistema
        </Text>

        <Text style={styles.texto}>
          O App Scholar é um sistema acadêmico
          desenvolvido para facilitar o gerenciamento
          das informações escolares.
        </Text>

        <Text style={styles.texto}>
          O sistema possui diferentes áreas de acesso
          para alunos, professores, responsáveis e
          coordenadores.
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitulo}>
          Módulos
        </Text>

        <Text style={styles.lista}>
          • Alunos{'\n'}
          • Professores{'\n'}
          • Responsáveis{'\n'}
          • Cursos{'\n'}
          • Disciplinas{'\n'}
          • Matrículas{'\n'}
          • Turmas{'\n'}
          • Avaliações{'\n'}
          • Boletins
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 28,
    alignItems: 'center',
  },

  voltar: {
    width: '100%',
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 30,
  },

  logo: {
    width: 85,
    height: 85,
    borderWidth: 2,
    borderColor: CORES.verde,
    borderRadius: 45,
    alignItems: 'center',
    justifyContent: 'center',
  },

  logoTexto: {
    fontSize: 27,
    fontWeight: 'bold',
    color: CORES.verde,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 20,
    letterSpacing: 2,
  },

  subtitulo: {
    color: CORES.cinza,
    fontSize: 11,
    letterSpacing: 2,
    marginTop: 5,
  },

  divisor: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%',
    marginVertical: 25,
  },

  linha: {
    flex: 1,
    height: 1,
    backgroundColor: CORES.borda,
  },

  simbolo: {
    color: CORES.verde,
    marginHorizontal: 10,
  },

  card: {
    width: '100%',
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 20,
    marginBottom: 15,
  },

  cardTitulo: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 10,
  },

  texto: {
    color: CORES.cinza,
    lineHeight: 23,
    marginBottom: 10,
  },

  lista: {
    color: CORES.cinza,
    lineHeight: 28,
  },
});
import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function DisciplinaScreen({
  disciplinas,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>DISCIPLINAS</Text>

      <Text style={styles.subtitulo}>
        Disciplinas acadêmicas
      </Text>

      {disciplinas.map((disciplina) => (
        <View style={styles.card} key={disciplina.id}>
          <Text style={styles.icone}>📚</Text>

          <View>
            <Text style={styles.nome}>
              {disciplina.nome}
            </Text>

            <Text style={styles.detalhe}>
              Curso: {disciplina.curso}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  icone: {
    fontSize: 27,
    marginRight: 15,
  },

  nome: {
    fontSize: 17,
    fontWeight: 'bold',
    color: CORES.verde,
  },

  detalhe: {
    color: CORES.cinza,
    marginTop: 5,
  },
});
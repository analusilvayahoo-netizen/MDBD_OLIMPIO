import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function ResponsavelScreen({
  responsaveis,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity
        onPress={() => navegar('dashboard')}
      >
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>
        RESPONSÁVEIS
      </Text>

      <Text style={styles.subtitulo}>
        Responsáveis cadastrados
      </Text>

      {responsaveis.map((responsavel) => (
        <View style={styles.card} key={responsavel.id}>
          <Text style={styles.icone}>👨‍👩‍👧</Text>

          <View>
            <Text style={styles.nome}>
              {responsavel.nome}
            </Text>

            <Text style={styles.detalhe}>
              Aluno: {responsavel.aluno}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginBottom: 25,
    marginTop: 5,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 18,
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    marginBottom: 12,
  },

  icone: {
    fontSize: 27,
    marginRight: 15,
  },

  nome: {
    fontSize: 16,
    color: CORES.verde,
    fontWeight: 'bold',
  },

  detalhe: {
    color: CORES.cinza,
    marginTop: 5,
  },
});
import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function TurmaScreen({
  turmas,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>TURMAS</Text>

      <Text style={styles.subtitulo}>
        Turmas cadastradas
      </Text>

      {turmas.map((turma) => (
        <View style={styles.card} key={turma.id}>
          <View style={styles.icone}>
            <Text>👥</Text>
          </View>

          <View>
            <Text style={styles.nome}>
              {turma.nome}
            </Text>

            <Text style={styles.detalhe}>
              Curso: {turma.curso}
            </Text>

            <Text style={styles.detalhe}>
              Professor: {turma.professor}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  icone: {
    width: 45,
    height: 45,
    borderRadius: 25,
    backgroundColor: '#EEF3EF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },

  nome: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 17,
  },

  detalhe: {
    color: CORES.cinza,
    marginTop: 4,
  },
});
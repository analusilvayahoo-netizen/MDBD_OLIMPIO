import React, { useState } from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';

const CORES = {
  fundo: '#FFFAFA',
  verde: '#0D2C1D',
  verdeClaro: '#183F2B',
  cinza: '#666666',
  borda: '#D5DDD8',
  branco: '#FFFFFF',
};

export default function LoginScreen({ navegar, fazerLogin }) {
  const [nome, setNome] = useState('');
  const [perfil, setPerfil] = useState('');

  function entrar() {
    if (!nome.trim()) {
      Alert.alert('Atenção', 'Digite seu nome.');
      return;
    }

    if (!perfil) {
      Alert.alert('Atenção', 'Selecione seu perfil.');
      return;
    }

    fazerLogin(perfil, nome);
  }

  const perfis = [
    {
      id: 'aluno',
      nome: 'ALUNO',
      simbolo: '🎓',
    },
    {
      id: 'professor',
      nome: 'PROFESSOR',
      simbolo: '📚',
    },
    {
      id: 'responsavel',
      nome: 'RESPONSÁVEL',
      simbolo: '👨‍👩‍👧',
    },
    {
      id: 'coordenador',
      nome: 'COORDENADOR',
      simbolo: '👩‍💼',
    },
  ];

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >

      {/* VOLTAR */}
      <TouchableOpacity
        onPress={() => navegar('home')}
        style={styles.voltar}
        activeOpacity={0.7}
      >
        <Text style={styles.voltarTexto}>
          ‹ Voltar
        </Text>
      </TouchableOpacity>

      {/* LOGO */}
      <View style={styles.logo}>
        <Text style={styles.logoTexto}>
          DV
        </Text>
      </View>

      {/* TÍTULO */}
      <Text style={styles.titulo}>
        APP SCHOLAR
      </Text>

      <Text style={styles.subtitulo}>
        ACESSO AO SISTEMA
      </Text>

      {/* NOME */}
      <Text style={styles.labelNome}>
        NOME
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite seu nome"
        placeholderTextColor="#888888"
        value={nome}
        onChangeText={setNome}
        autoCapitalize="words"
      />

      {/* PERFIL */}
      <Text style={styles.label}>
        SELECIONE SEU PERFIL
      </Text>

      {perfis.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.perfil,
            perfil === item.id && styles.perfilSelecionado,
          ]}
          onPress={() => setPerfil(item.id)}
          activeOpacity={0.7}
        >

          <Text style={styles.simbolo}>
            {item.simbolo}
          </Text>

          <Text
            style={[
              styles.perfilTexto,
              perfil === item.id &&
                styles.perfilTextoSelecionado,
            ]}
          >
            {item.nome}
          </Text>

        </TouchableOpacity>
      ))}

      {/* BOTÃO */}
      <TouchableOpacity
        style={styles.botao}
        onPress={entrar}
        activeOpacity={0.8}
      >
        <Text style={styles.botaoTexto}>
          ENTRAR
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 28,
    paddingBottom: 40,
    alignItems: 'center',
  },

  voltar: {
    width: '100%',
    marginBottom: 35,
  },

  voltarTexto: {
    color: CORES.verde,
    fontSize: 16,
    fontWeight: 'bold',
  },

  logo: {
    width: 75,
    height: 75,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: CORES.verde,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },

  logoTexto: {
    fontSize: 25,
    fontWeight: 'bold',
    color: CORES.verde,
    letterSpacing: 2,
  },

  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    color: CORES.verde,
    letterSpacing: 2,
    textAlign: 'center',
  },

  subtitulo: {
    color: CORES.cinza,
    fontSize: 12,
    letterSpacing: 2,
    marginBottom: 35,
    marginTop: 8,
  },

  labelNome: {
    width: '100%',
    fontSize: 12,
    color: CORES.cinza,
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: 8,
  },

  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 8,
    padding: 15,
    fontSize: 16,
    backgroundColor: CORES.branco,
    marginBottom: 25,
    color: '#222222',
  },

  label: {
    width: '100%',
    fontSize: 12,
    color: CORES.cinza,
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: 12,
  },

  perfil: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 8,
    padding: 16,
    marginBottom: 10,
    backgroundColor: CORES.branco,
  },

  perfilSelecionado: {
    borderColor: CORES.verde,
    backgroundColor: '#EEF3EF',
  },

  simbolo: {
    fontSize: 22,
    marginRight: 15,
  },

  perfilTexto: {
    color: CORES.cinza,
    fontWeight: 'bold',
    letterSpacing: 1,
    fontSize: 14,
  },

  perfilTextoSelecionado: {
    color: CORES.verde,
  },

  botao: {
    width: '100%',
    backgroundColor: CORES.verde,
    paddingVertical: 17,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },

  botaoTexto: {
    color: CORES.fundo,
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 2,
  },

});
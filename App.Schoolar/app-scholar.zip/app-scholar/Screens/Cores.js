export const CORES = {
  fundo: '#FFFAFA',
  verde: '#0D2C1D',
  verdeClaro: '#183F2B',
  cinza: '#666666',
  borda: '#D5DDD8',
  branco: '#FFFFFF',
};
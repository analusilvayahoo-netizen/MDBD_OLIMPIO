import React, { useState } from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function CoordenadorScreen({
  usuario,
  navegar,
}) {
  if (usuario.perfil !== 'coordenador') {
    return (
      <View style={styles.bloqueado}>
        <Text style={styles.icone}>🔒</Text>

        <Text style={styles.titulo}>
          ACESSO NEGADO
        </Text>

        <Text style={styles.texto}>
          Esta área é exclusiva para coordenadores.
        </Text>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => navegar('dashboard')}
        >
          <Text style={styles.botaoTexto}>
            VOLTAR
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>
        ÁREA DO COORDENADOR
      </Text>

      <Text style={styles.subtitulo}>
        Administração acadêmica
      </Text>

      <View style={styles.destaque}>
        <Text style={styles.destaqueTitulo}>
          Acesso administrativo
        </Text>

        <Text style={styles.destaqueTexto}>
          O coordenador possui acesso aos
          principais módulos do sistema.
        </Text>
      </View>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navegar('alunos')}
      >
        <Text style={styles.icone}>🎓</Text>

        <View>
          <Text style={styles.cardTitulo}>
            Gerenciar alunos
          </Text>

          <Text style={styles.cardTexto}>
            Cadastrar e consultar alunos
          </Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navegar('professores')}
      >
        <Text style={styles.icone}>👨‍🏫</Text>

        <View>
          <Text style={styles.cardTitulo}>
            Gerenciar professores
          </Text>

          <Text style={styles.cardTexto}>
            Consultar professores
          </Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navegar('cursos')}
      >
        <Text style={styles.icone}>🏫</Text>

        <View>
          <Text style={styles.cardTitulo}>
            Gerenciar cursos
          </Text>

          <Text style={styles.cardTexto}>
            Consultar cursos
          </Text>
        </View>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 27,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  destaque: {
    backgroundColor: CORES.verde,
    borderRadius: 12,
    padding: 22,
    marginBottom: 20,
  },

  destaqueTitulo: {
    color: CORES.fundo,
    fontSize: 19,
    fontWeight: 'bold',
  },

  destaqueTexto: {
    color: CORES.fundo,
    marginTop: 8,
    lineHeight: 21,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: CORES.borda,
    backgroundColor: CORES.branco,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  icone: {
    fontSize: 28,
    marginRight: 15,
  },

  cardTitulo: {
    color: CORES.verde,
    fontSize: 16,
    fontWeight: 'bold',
  },

  cardTexto: {
    color: CORES.cinza,
    marginTop: 4,
  },

  bloqueado: {
    flex: 1,
    backgroundColor: CORES.fundo,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },

  texto: {
    color: CORES.cinza,
    textAlign: 'center',
    marginVertical: 15,
  },

  botao: {
    backgroundColor: CORES.verde,
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 8,
  },

  botaoTexto: {
    color: CORES.fundo,
    fontWeight: 'bold',
  },
});
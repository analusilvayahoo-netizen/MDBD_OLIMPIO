import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function AvaliacaoScreen({
  avaliacoes,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>AVALIAÇÕES</Text>

      <Text style={styles.subtitulo}>
        Notas e avaliações
      </Text>

      {avaliacoes.map((avaliacao) => (
        <View style={styles.card} key={avaliacao.id}>
          <View style={styles.info}>
            <Text style={styles.aluno}>
              {avaliacao.aluno}
            </Text>

            <Text style={styles.disciplina}>
              {avaliacao.disciplina}
            </Text>
          </View>

          <View style={styles.nota}>
            <Text style={styles.notaTexto}>
              {avaliacao.nota}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  info: {
    flex: 1,
  },

  aluno: {
    color: CORES.verde,
    fontSize: 16,
    fontWeight: 'bold',
  },

  disciplina: {
    color: CORES.cinza,
    marginTop: 5,
  },

  nota: {
    width: 55,
    height: 55,
    borderRadius: 30,
    backgroundColor: CORES.verde,
    alignItems: 'center',
    justifyContent: 'center',
  },

  notaTexto: {
    color: CORES.fundo,
    fontSize: 17,
    fontWeight: 'bold',
  },
});
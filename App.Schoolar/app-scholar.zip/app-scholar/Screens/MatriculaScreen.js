import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { CORES } from './Cores';

export default function MatriculaScreen({
  matriculas,
  navegar,
}) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.conteudo}
    >
      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>‹ Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>MATRÍCULAS</Text>

      <Text style={styles.subtitulo}>
        Matrículas dos alunos
      </Text>

      {matriculas.map((matricula) => (
        <View style={styles.card} key={matricula.id}>
          <Text style={styles.numero}>
            #{matricula.id}
          </Text>

          <View style={styles.info}>
            <Text style={styles.nome}>
              {matricula.aluno}
            </Text>

            <Text style={styles.detalhe}>
              {matricula.curso}
            </Text>

            <Text style={styles.detalhe}>
              Ano letivo: {matricula.ano}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  conteudo: {
    padding: 25,
  },

  voltar: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 25,
  },

  titulo: {
    color: CORES.verde,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitulo: {
    color: CORES.cinza,
    marginTop: 5,
    marginBottom: 25,
  },

  card: {
    flexDirection: 'row',
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 18,
    marginBottom: 12,
  },

  numero: {
    color: CORES.verde,
    fontWeight: 'bold',
    marginRight: 15,
  },

  info: {
    flex: 1,
  },

  nome: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 16,
  },

  detalhe: {
    color: CORES.cinza,
    marginTop: 4,
  },
});
import React, { useState } from 'react';
import { Image } from 'react-native';

import HomeScreen from './Screens/HomeScreen';
import LoginScreen from './Screens/LoginScreen';
import DashboardScreen from './Screens/DashboardScreen';
import AlunoScreen from './Screens/AlunoScreen';
import ProfessorScreen from './Screens/ProfessorScreen';
import ResponsavelScreen from './Screens/ResponsavelScreen';
import CoordenadorScreen from './Screens/CoordenadorScreen';
import CursoScreen from './Screens/CursoScreen';
import DisciplinaScreen from './Screens/DisciplinaScreen';
import MatriculaScreen from './Screens/MatriculaScreen';
import TurmaScreen from './Screens/TurmaScreen';
import AvaliacaoScreen from './Screens/AvaliacaoScreen';
import BoletimScreen from './Screens/BoletimScreen';
import SobreScreen from './Screens/SobreScreen';


import logo from './logo.png';

import { CORES } from './Screens/Cores';

export default function App() {
  const [tela, setTela] = useState('home');
  const [usuario, setUsuario] = useState(null);

  const [alunos, setAlunos] = useState([
    {
      id: 1,
      nome: 'Ana Luiza',
      idade: '17',
      email: 'ana@email.com',
      turma: '3º A',
    },
    {
      id: 2,
      nome: 'João Pedro',
      idade: '16',
      email: 'joao@email.com',
      turma: '2º B',
    },
  ]);

  const [professores] = useState([
    { id: 1, nome: 'Carlos Eduardo', disciplina: 'Matemática' },
    { id: 2, nome: 'Mariana Silva', disciplina: 'Português' },
  ]);

  const [responsaveis] = useState([
    { id: 1, nome: 'Maria Oliveira', aluno: 'Ana Luiza' },
    { id: 2, nome: 'José Santos', aluno: 'João Pedro' },
  ]);

  const [cursos] = useState([
    { id: 1, nome: 'Ensino Médio', descricao: 'Formação geral' },
    { id: 2, nome: 'Ensino Fundamental', descricao: 'Formação básica' },
  ]);

  const [disciplinas] = useState([
    { id: 1, nome: 'Matemática', curso: 'Ensino Médio' },
    { id: 2, nome: 'Português', curso: 'Ensino Médio' },
    { id: 3, nome: 'História', curso: 'Ensino Médio' },
  ]);

  const [matriculas] = useState([
    { id: 1, aluno: 'Ana Luiza', curso: 'Ensino Médio', ano: '2026' },
    { id: 2, aluno: 'João Pedro', curso: 'Ensino Médio', ano: '2026' },
  ]);

  const [turmas] = useState([
    {
      id: 1,
      nome: '3º A',
      curso: 'Ensino Médio',
      professor: 'Carlos Eduardo',
    },
    {
      id: 2,
      nome: '2º B',
      curso: 'Ensino Médio',
      professor: 'Mariana Silva',
    },
  ]);

  const [avaliacoes] = useState([
    {
      id: 1,
      aluno: 'Ana Luiza',
      disciplina: 'Matemática',
      nota: '8,5',
    },
    {
      id: 2,
      aluno: 'Ana Luiza',
      disciplina: 'Português',
      nota: '9,0',
    },
    {
      id: 3,
      aluno: 'João Pedro',
      disciplina: 'Matemática',
      nota: '7,5',
    },
  ]);

  const [boletins] = useState([
    {
      id: 1,
      aluno: 'Ana Luiza',
      media: '8,25',
      situacao: 'Aprovada',
    },
    {
      id: 2,
      aluno: 'João Pedro',
      media: '7,50',
      situacao: 'Aprovado',
    },
  ]);

  function navegar(nomeTela) {
    setTela(nomeTela);
  }

  function fazerLogin(perfil, nome) {
    setUsuario({
      nome,
      perfil,
    });

    setTela('dashboard');
  }

  function sair() {
    setUsuario(null);
    setTela('home');
  }

  function adicionarAluno(aluno) {
    setAlunos((lista) => [
      ...lista,
      {
        ...aluno,
        id: Date.now(),
      },
    ]);
  }

  function excluirAluno(id) {
    setAlunos((lista) =>
      lista.filter((aluno) => aluno.id !== id)
    );
  }

  // HOME
  if (tela === 'home') {
    return (
      <HomeScreen
        navegar={navegar}
        logo={logo}
      />
    );
  }

  // LOGIN
  if (tela === 'login') {
    return (
      <LoginScreen
        navegar={navegar}
        fazerLogin={fazerLogin}
      />
    );
  }

  // SOBRE
  if (tela === 'sobre') {
    return (
      <SobreScreen
        navegar={navegar}
      />
    );
  }

  // Se não estiver logado
  if (!usuario) {
    return (
      <LoginScreen
        navegar={navegar}
        fazerLogin={fazerLogin}
      />
    );
  }

  // DASHBOARD
  if (tela === 'dashboard') {
    return (
      <DashboardScreen
        usuario={usuario}
        navegar={navegar}
        sair={sair}
      />
    );
  }

  // ALUNOS
  if (tela === 'alunos') {
    return (
      <AlunoScreen
        usuario={usuario}
        alunos={alunos}
        adicionarAluno={adicionarAluno}
        excluirAluno={excluirAluno}
        navegar={navegar}
      />
    );
  }

  // PROFESSORES
  if (tela === 'professores') {
    return (
      <ProfessorScreen
        usuario={usuario}
        professores={professores}
        navegar={navegar}
      />
    );
  }

  // RESPONSÁVEIS
  if (tela === 'responsaveis') {
    return (
      <ResponsavelScreen
        usuario={usuario}
        responsaveis={responsaveis}
        navegar={navegar}
      />
    );
  }

  // COORDENADOR
  if (tela === 'coordenador') {
    return (
      <CoordenadorScreen
        usuario={usuario}
        navegar={navegar}
      />
    );
  }

  // CURSOS
  if (tela === 'cursos') {
    return (
      <CursoScreen
        usuario={usuario}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }

  // DISCIPLINAS
  if (tela === 'disciplinas') {
    return (
      <DisciplinaScreen
        usuario={usuario}
        disciplinas={disciplinas}
        navegar={navegar}
      />
    );
  }

  // MATRÍCULAS
  if (tela === 'matriculas') {
    return (
      <MatriculaScreen
        usuario={usuario}
        matriculas={matriculas}
        navegar={navegar}
      />
    );
  }

  // TURMAS
  if (tela === 'turmas') {
    return (
      <TurmaScreen
        usuario={usuario}
        turmas={turmas}
        navegar={navegar}
      />
    );
  }

  // AVALIAÇÕES
  if (tela === 'avaliacoes') {
    return (
      <AvaliacaoScreen
        usuario={usuario}
        avaliacoes={avaliacoes}
        navegar={navegar}
      />
    );
  }

  // BOLETINS
  if (tela === 'boletins') {
    return (
      <BoletimScreen
        usuario={usuario}
        boletins={boletins}
        navegar={navegar}
      />
    );
  }

  return null;
}